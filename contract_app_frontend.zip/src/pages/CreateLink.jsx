import React from 'react';

const CreateLink = () => <div>CreateLink Page (to be implemented)</div>;

export default CreateLink;