import React from 'react';

const MeetingViewer = () => <div>MeetingViewer Page (to be implemented)</div>;

export default MeetingViewer;