import React from 'react';

const Dashboard = () => <div>Dashboard Page (to be implemented)</div>;

export default Dashboard;