import React from 'react';

const PublicScheduler = () => <div>PublicScheduler Page (to be implemented)</div>;

export default PublicScheduler;